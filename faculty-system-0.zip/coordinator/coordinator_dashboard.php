<?php
include '../config.php';
include '../auth_check.php';

// Ensure only coordinators can access
if ($_SESSION['role'] !== 'coordinator') {
    header("Location: ../auth/coordinator_login.php");
    exit;
}

// Get dashboard statistics
$dept_id = $_SESSION['department_id'];

// Total projects
$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM projects WHERE department_id = ?");
$stmt->execute([$dept_id]);
$total_projects = $stmt->fetch()['total'];

// Available projects
$stmt = $pdo->prepare("SELECT COUNT(*) as available FROM projects WHERE department_id = ? AND availability_status = 'available'");
$stmt->execute([$dept_id]);
$available_projects = $stmt->fetch()['available'];

// Pending bookings
$stmt = $pdo->prepare("SELECT COUNT(*) as pending FROM bookings WHERE booking_status = 'pending' AND project_id IN (SELECT id FROM projects WHERE department_id = ?)");
$stmt->execute([$dept_id]);
$pending_bookings = $stmt->fetch()['pending'];

// Pending topic proposals
$stmt = $pdo->prepare("SELECT COUNT(*) as pending FROM proposed_topics WHERE department_id = ? AND status = 'pending'");
$stmt->execute([$dept_id]);
$pending_topics = $stmt->fetch()['pending'];

// Total students
$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM users WHERE department_id = ? AND role = 'student'");
$stmt->execute([$dept_id]);
$total_students = $stmt->fetch()['total'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coordinator Dashboard - Faculty Project System</title>
    <link rel="stylesheet" href="../styles.css">
</head>
<body>
    <?php include 'navbar_coordinator.php'; ?>
    
    <div class="container">
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?></h1>
        <p>Department: <?php echo htmlspecialchars($_SESSION['department_name']); ?></p>
        
        <div class="dashboard-stats">
            <div class="stat-card">
                <h3>Total Projects</h3>
                <p class="stat-number"><?php echo $total_projects; ?></p>
            </div>
            
            <div class="stat-card">
                <h3>Available Projects</h3>
                <p class="stat-number"><?php echo $available_projects; ?></p>
            </div>
            
            <div class="stat-card">
                <h3>Pending Bookings</h3>
                <p class="stat-number"><?php echo $pending_bookings; ?></p>
            </div>
            
            <div class="stat-card">
                <h3>Pending Topics</h3>
                <p class="stat-number"><?php echo $pending_topics; ?></p>
            </div>
            
            <div class="stat-card">
                <h3>Total Students</h3>
                <p class="stat-number"><?php echo $total_students; ?></p>
            </div>
        </div>
        
        <div class="quick-actions">
            <h2>Quick Actions</h2>
            <div class="action-buttons">
                <a href="projects_list.php" class="btn btn-primary">Manage Projects</a>
                <a href="students_list.php" class="btn btn-primary">Manage Students</a>
                <a href="borrowings_list.php" class="btn btn-primary">View Borrowings</a>
                <a href="topic_proposals_list.php" class="btn btn-primary">Review Topics</a>
            </div>
        </div>
    </div>
</body>
</html>