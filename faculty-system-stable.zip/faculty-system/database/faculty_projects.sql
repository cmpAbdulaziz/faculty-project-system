-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2025 at 12:49 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `faculty_projects`
--

-- --------------------------------------------------------

--
-- Table structure for table `approved_topics`
--

CREATE TABLE `approved_topics` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `case_study` varchar(255) DEFAULT NULL,
  `student_id` int(11) NOT NULL,
  `supervisor_name` varchar(255) NOT NULL,
  `date_of_approval` date DEFAULT NULL,
  `department_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `approved_topics`
--

INSERT INTO `approved_topics` (`id`, `title`, `case_study`, `student_id`, `supervisor_name`, `date_of_approval`, `department_id`) VALUES
(1, 'AI-Based Course Recommendation System', 'Computer Science Department', 6, 'Dr. Smart AI', '2025-11-23', 1),
(2, 'online repair person and customer connetion system', 'hajiya halima sokoto state', 8, 'Dr. Ahmed Bello', '2025-11-12', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `project_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `booking_status` enum('pending','collected','expired','returned') NOT NULL DEFAULT 'pending',
  `booked_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime NOT NULL,
  `collected_at` datetime DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `returned_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `project_id`, `student_id`, `booking_status`, `booked_at`, `expires_at`, `collected_at`, `due_date`, `returned_at`) VALUES
(1, 1, 6, 'returned', '2025-11-23 08:07:30', '2025-11-23 11:07:30', '2025-11-23 09:55:33', '2025-11-30 09:55:33', '2025-11-23 10:01:02'),
(2, 1, 8, 'collected', '2025-11-23 10:59:23', '2025-11-23 13:59:41', '2025-11-23 12:00:52', '2025-11-30 12:00:52', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `coordinator_availability`
--

CREATE TABLE `coordinator_availability` (
  `id` int(11) NOT NULL,
  `coordinator_id` int(11) NOT NULL,
  `status` enum('available','unavailable') NOT NULL DEFAULT 'unavailable',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coordinator_availability`
--

INSERT INTO `coordinator_availability` (`id`, `coordinator_id`, `status`, `updated_at`) VALUES
(1, 1, 'unavailable', '2025-11-23 11:29:09'),
(2, 2, 'unavailable', '2025-11-23 02:56:12'),
(3, 3, 'unavailable', '2025-11-23 02:56:12'),
(4, 4, 'unavailable', '2025-11-23 02:56:12'),
(5, 5, 'unavailable', '2025-11-23 02:56:12');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `coordinator_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `coordinator_id`, `created_at`) VALUES
(1, 'Computer Science', 1, '2025-11-23 02:56:11'),
(2, 'Statistics', 2, '2025-11-23 02:56:11'),
(3, 'Mathematics', 3, '2025-11-23 02:56:11'),
(4, 'Geology', 4, '2025-11-23 02:56:11'),
(5, 'Physics', 5, '2025-11-23 02:56:11');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `supervisor_name` varchar(255) NOT NULL,
  `year_of_submission` year(4) DEFAULT NULL,
  `availability_status` enum('available','borrowed','booked') NOT NULL DEFAULT 'available',
  `department_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `title`, `student_name`, `supervisor_name`, `year_of_submission`, `availability_status`, `department_id`, `created_at`) VALUES
(1, 'Web-Based Student Management System', 'Aliyu Mohammed', 'Dr. Ahmed Bello', '2024', 'borrowed', 1, '2025-11-23 02:56:11'),
(2, 'Data Analysis of Student Performance', 'Fatima Sani', 'Dr. John Okoro', '2023', 'available', 2, '2025-11-23 02:56:11');

-- --------------------------------------------------------

--
-- Table structure for table `proposed_topics`
--

CREATE TABLE `proposed_topics` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `case_study` varchar(255) DEFAULT NULL,
  `student_id` int(11) NOT NULL,
  `supervisor_name` varchar(255) NOT NULL,
  `problem_statement` text NOT NULL,
  `topic_objectives` text NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `department_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `proposed_topics`
--

INSERT INTO `proposed_topics` (`id`, `title`, `case_study`, `student_id`, `supervisor_name`, `problem_statement`, `topic_objectives`, `status`, `department_id`, `created_at`) VALUES
(1, 'AI-Based Course Recommendation System', 'Computer Science Department', 6, 'Dr. Smart AI', 'Students struggle to choose appropriate courses...', 'Develop AI system to recommend courses...', 'approved', 1, '2025-11-23 02:56:11'),
(2, 'home maitaina', 'udus', 8, 'mal. surajo', 'so many homes lack maintanance', 'to automate the maintainance process', 'rejected', 1, '2025-11-23 10:47:52'),
(3, 'ai integration', 'udus', 8, 'mal. surajo', 'student at udus lack guidance', 'ai will guide them', 'approved', 1, '2025-11-23 10:55:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone_number` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('student','coordinator') NOT NULL DEFAULT 'student',
  `admission_no` varchar(50) DEFAULT NULL,
  `department_id` int(11) NOT NULL,
  `is_suspended` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `email`, `phone_number`, `password`, `role`, `admission_no`, `department_id`, `is_suspended`, `created_at`) VALUES
(1, 'Dr. Computer Science Coordinator', 'cs_coordinator@udusok.edu.ng', '08011111111', 'coordinator123', 'coordinator', NULL, 1, 0, '2025-11-23 02:56:11'),
(2, 'Dr. Statistics Coordinator', 'stats_coordinator@udusok.edu.ng', '08022222222', 'coordinator123', 'coordinator', NULL, 2, 0, '2025-11-23 02:56:11'),
(3, 'Dr. Mathematics Coordinator', 'math_coordinator@udusok.edu.ng', '08033333333', 'coordinator123', 'coordinator', NULL, 3, 0, '2025-11-23 02:56:11'),
(4, 'Dr. Geology Coordinator', 'geo_coordinator@udusok.edu.ng', '08044444444', 'coordinator123', 'coordinator', NULL, 4, 0, '2025-11-23 02:56:11'),
(5, 'Dr. Physics Coordinator', 'physics_coordinator@udusok.edu.ng', '08055555555', 'coordinator123', 'coordinator', NULL, 5, 0, '2025-11-23 02:56:11'),
(6, 'Test CS Student', 'cs_student@udusok.edu.ng', '08066666666', 'student123', 'student', 'UGP/CS/2020/001', 1, 0, '2025-11-23 02:56:11'),
(7, 'Test Stats Student', 'stats_student@udusok.edu.ng', '08077777777', 'student123', 'student', 'UGP/STAT/2020/001', 2, 0, '2025-11-23 02:56:11'),
(8, 'ahmad abdulaziz', 'abdulazizahmad862@gmail.com', '07098989854', 'abdul12345', 'student', 'UCP/CS/2020/0007', 1, 0, '2025-11-23 09:45:38'),
(9, 'uopo hgjjh', 'oooo.or@udusok.edu.ng', '4757888877', '123', 'student', 'UCP/CS/2020/0008', 1, 0, '2025-11-23 11:05:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approved_topics`
--
ALTER TABLE `approved_topics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `coordinator_availability`
--
ALTER TABLE `coordinator_availability`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `coordinator_id` (`coordinator_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `coordinator_id` (`coordinator_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `proposed_topics`
--
ALTER TABLE `proposed_topics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `admission_no` (`admission_no`),
  ADD KEY `department_id` (`department_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approved_topics`
--
ALTER TABLE `approved_topics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `coordinator_availability`
--
ALTER TABLE `coordinator_availability`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `proposed_topics`
--
ALTER TABLE `proposed_topics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `approved_topics`
--
ALTER TABLE `approved_topics`
  ADD CONSTRAINT `approved_topics_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `approved_topics_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `coordinator_availability`
--
ALTER TABLE `coordinator_availability`
  ADD CONSTRAINT `coordinator_availability_ibfk_1` FOREIGN KEY (`coordinator_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `departments_ibfk_1` FOREIGN KEY (`coordinator_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `proposed_topics`
--
ALTER TABLE `proposed_topics`
  ADD CONSTRAINT `proposed_topics_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `proposed_topics_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
